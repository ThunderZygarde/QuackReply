duck_facts = [
      "All ducks have highly waterproof feathers. A duck's feathers are so waterproof that even when the duck dives underwater, the downy underlayer of feathers right next to the skin will stay completely dry.",

      "Ducks are omnivorous and will eat grass, aquatic plants, insects, seeds, fruit, fish, crustaceans and other types of food.",
      
      "Ducklings younger than 10 days tend to swim and walk as a group, always close to their mother, to avoid the attack of predators.",

      "Most duck species are monogamous for a breeding season but they do not often mate for life. Instead, they will seek out new mates each year, choosing the healthiest, strongest, best mate who can help them pass on their genes to a new duckling generation.",

      "Ducks are outgoing, social animals who feel most at ease when they're in a larger group of other ducks.",
      
      "Ducks are birds. Ducks are also called ‘waterfowl’ because they are normally found in places where there is water like ponds, streams, and rivers.",
    
      "Ducks can live up to 20 years, depending on the species and if well cared for.",

      "The production of eggs is affected by daylight. When there is more daylight, the ducks will lay more eggs. To prevent this from happening, farmers use artificial lighting so that the ducks have about 17 hours of light a day to produce eggs efficiently.",

      "The eggs will hatch within 28 days normally, except for the Muscovy duck which takes about 35 days to hatch. The mother duck will keep her brood of ducklings together to protect them from predators.",

      "Ducks have been domesticated as pets and farm animals for more than 500 years, and all domestic ducks are descended from either the mallard or the Muscovy duck. Mallards, especially, are easy to crossbreed with other types of ducks, and mallards often hybridize with all types of ducks at local ponds."
]

#Facts Received from: https://www.four-paws.org/campaigns-topics/topics/farm-animals/10-facts-about-ducks#:~:text=Ducks%20are%20also%20called%20'waterfowl,ducks%20will%20lay%20more%20eggs.

sad_words = ["sad", "depressed", "unhappy", "angry", "miserable", "depressed"]

bad_words = ["bitch",  "cunt", "fag", "faggot",  "pussie", "pussy", "retard", "twat", "whore", "fuck", "shit", "asshole", "bastard", "motherquacker", "quack you"]

helpp = [
  "Here are the list of interactions:\n - Hello\n - Inspire: Shows a good quote taken from API stuff I just learned today \n - Common swear words (motherquacker, quack you, etc)\n - Common sad words (sad, depressed, unhappy... etc): This will trigger a supportive sentence.\n - $new, $list, $del: These will add, delete, and see the list of the supportive sentences that you add. $new (new sentence), $list, $del (number from 0 - n) with n being the number of sentences you add\n - Duckfact: shows a random duck fact."]