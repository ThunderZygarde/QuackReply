import discord
import os
import requests 
import json
import random
from replit import db
from keep_alive import keep_alive
from word_list import sad_words, bad_words, duck_facts, helpp

client = discord.Client()

starter_encouragements = [
  "Everything is gonna be okay, Quack Quack",
  "Don't worry, Quack"
]

if "responding" not in db.keys():
  db["responding"] = True

swear_detection = [
  "QUACK QUACK, NO BAD WORDS",
  "BAD WORDS DETECTED, QUACK",
  "QUACK YOU, YOU SAID A BAD WORD"
]

def get_quote():
  response = requests.get("https://zenquotes.io/api/random")
  json_data = json.loads(response.text)
  quote = json_data[0]['q'] + " -" + json_data[0]['a']
  return(quote)

def update_encouragements(encouraging_message):
  if "encouragements" in db.keys():
     encouragements = db["encouragements"]
     encouragements.append(encouraging_message)
     db["encouragements"] = encouragements
  else:
    db["encouragements"] = [encouraging_message]

def delete_encouragement(index):
  encouragements = db["encouragements"]
  if len(encouragements) > index:
    del encouragements[index]
  db["encouragements"] = encouragements

@client.event
async def on_ready():
  print ('{0.user} is gonna quack you up'.format(client))

  @client.event
  async def on_message(message):
    if message.author == client.user:
      return
      
    msg = message.content
    mesg = message.content.lower()

    if mesg.startswith('hello'):
      await message.channel.send('Quack!')

    if mesg.startswith('inspire'):
       quote = get_quote()
       await message.channel.send(quote)
    
    if any(word in mesg for word in bad_words):
      await message.channel.send(random.choice(swear_detection))

    if mesg.startswith("duckfact"):
      await message.channel.send(random.choice(duck_facts))

    if mesg.startswith("duckhelp"):
      await message.channel.send(random.choice(helpp))

    if db["responding"]:
      options = starter_encouragements
      if "encouragements" in db.keys():
        options = options + db["encouragements"].value

      if any(word in mesg for word in sad_words):
        await message.channel.send(random.choice(options))

    if msg.startswith("$new"):
      encouraging_message = msg.split("$new ",1)[1]
      update_encouragements(encouraging_message)
      await message.channel.send("New encouraging message added.")

    if msg.startswith("$del"):
      encouragements = []
      if "encouragements" in db.keys():
        index = int(msg.split("$del",1)[1])
        delete_encouragement(index)
        encouragements = db["encouragements"]
      await message.channel.send(encouragements)

    if msg.startswith("$list"):
      encouragements = [];
      if "encouragements" in db.keys():
        encouragements = db["encouragements"]
      await message.channel.send(encouragements)

    if msg.startswith("$responding"):
      value = msg.split("$responding ", 1)[1]

      if value.lower() == "true":
        db["responding"] = True
        await message.channel.send("Responding is on, Quack")
      else:
        db["responding"] = False
        await message.channel.send("Responding is off, Quack")
      

      keep_alive()
client.run(os.getenv('TOKEN'))
